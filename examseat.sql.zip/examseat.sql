-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2019 at 04:07 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `examseat`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` varchar(5) NOT NULL,
  `branch_name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_name`) VALUES
('1', 'cse'),
('2', 'ece'),
('3', 'mech'),
('4', 'civ'),
('5', 'ise');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `faculty_name` varchar(20) DEFAULT NULL,
  `faculty_id` varchar(5) NOT NULL,
  `branch_id` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`faculty_name`, `faculty_id`, `branch_id`) VALUES
('lakshmi', '101', '1'),
('lakshmikanth', '102', '2'),
('pavithra', '103', '3'),
('arpitha', '104', '4'),
('suresh', '105', '5');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` varchar(5) NOT NULL,
  `room_name` varchar(20) DEFAULT NULL,
  `seats` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `room_name`, `seats`) VALUES
('1', 'eh01', '5'),
('2', 'eh02', '5'),
('3', 'eh03', '5'),
('4', 'eh04', '5'),
('5', 'eh05', '5'),
('6', 'eh06', '5'),
('7', 'eh07', '5');

--
-- Triggers `room`
--
DELIMITER $$
CREATE TRIGGER `tt` AFTER INSERT ON `room` FOR EACH ROW INSERT INTO roomtrigger VALUES(NEW.rOom_id,NEW.room_name,'Inserted',NOW())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `ttt` AFTER UPDATE ON `room` FOR EACH ROW INSERT into roomtrigger values(new.room_id,new.room_name,'Updated',now())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `roomallocation`
--

CREATE TABLE `roomallocation` (
  `subject_id` varchar(10) DEFAULT NULL,
  `total_students` varchar(10) DEFAULT NULL,
  `room_id` varchar(5) DEFAULT NULL,
  `faculty_id` varchar(5) DEFAULT NULL,
  `usn` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roomallocation`
--

INSERT INTO `roomallocation` (`subject_id`, `total_students`, `room_id`, `faculty_id`, `usn`) VALUES
('17cs51', '5', '2', '102', '1vk17cs002'),
('17cs51', '5', '3', '103', '1vk17cs003'),
('17cs51', '5', '4', '104', '1vk17cs007'),
('17cs51', '5', '5', '105', '1vk17cs008'),
('17cs52', '5', '2', '102', '1vk17cs004'),
('17cs52', '5', '3', '103', '1vk17cs006'),
('17cs52', '5', '4', '104', '1vk17cs009'),
('17cs52', '5', '5', '105', '1vk17cs010'),
('17cs53', '5', '2', '102', '1vk17cs012'),
('17cs53', '5', '3', '103', '1vk17cs013'),
('17cs53', '5', '4', '104', '1vk17cs014'),
('17cs53', '5', '5', '105', '1vk17cs015'),
('17cs54', '5', '5', '105', '1vk17cs016'),
('17cs54', '5', '2', '102', '1vk17cs018'),
('17cs54', '5', '3', '103', '1vk17cs019'),
('17cs54', '5', '4', '104', '1vk17cs020'),
('17cs55', '5', '4', '104', '1vk17cs021'),
('17cs55', '5', '5', '105', '1vk17cs022'),
('17cs55', '5', '2', '102', '1vk17cs024'),
('17cs55', '5', '3', '103', '1vk17cs025'),
('17cs61', '5', '2', '102', '1vk17cs022'),
('17cs52', '5', '5', '105', '1vk17cs020'),
('17cs55', '5', '6', '105', '1vk17cs001'),
('17cs55', '5', '6', '105', '1vk17cs002'),
('17cs57', '5', '7', '104', '1vk17cs009'),
('17cs57', '5', '7', '104', '1vk17cs010'),
('17cs57', '5', '7', '104', '1vk17cs011'),
('17cs61', '5', '4', '103', '1vk17cs025'),
('17cs61', '5', '4', '103', '1vk17cs024'),
('17cs61', '5', '4', '103', '1vk17cs023');

-- --------------------------------------------------------

--
-- Table structure for table `roomtrigger`
--

CREATE TABLE `roomtrigger` (
  `room_id` int(11) NOT NULL,
  `room_name` varchar(11) NOT NULL,
  `Action` varchar(20) NOT NULL,
  `c_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roomtrigger`
--

INSERT INTO `roomtrigger` (`room_id`, `room_name`, `Action`, `c_date`) VALUES
(1, 'eh01', 'Inserted', '2019-12-08 20:22:02'),
(6, 'eh06', 'Updated', '2019-12-08 20:21:56');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `usn` varchar(15) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `sem` varchar(10) DEFAULT NULL,
  `branch_id` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`usn`, `name`, `sem`, `branch_id`) VALUES
('1vk17cs001', 'adarsh', '1', '1'),
('1vk17cs002', 'ajith', '1', '1'),
('1vk17cs003', 'ajmal', '1', '1'),
('1vk17cs004', 'anil', '2', '2'),
('1vk17cs005', 'ankith', '2', '2'),
('1vk17cs006', 'ankitha', '2', '2'),
('1vk17cs007', 'anusha', '1', '1'),
('1vk17cs008', 'bhoomika', '1', '1'),
('1vk17cs009', 'kumar', '2', '2'),
('1vk17cs010', 'avinash', '2', '2'),
('1vk17cs011', 'raj', '3', '3'),
('1vk17cs012', 'rajesh', '3', '3'),
('1vk17cs013', 'manjunath', '3', '3'),
('1vk17cs014', 'bharath', '3', '3'),
('1vk17cs015', 'bharathgowda', '3', '3'),
('1vk17cs016', 'mahesh', '4', '4'),
('1vk17cs017', 'manu', '4', '4'),
('1vk17cs018', 'manoj', '4', '4'),
('1vk17cs019', 'jagadish', '4', '4'),
('1vk17cs020', 'jaswanth', '4', '4'),
('1vk17cs021', 'kotresh', '5', '5'),
('1vk17cs022', 'prajay', '5', '5'),
('1vk17cs023', 'monish', '5', '5'),
('1vk17cs024', 'gokul', '5', '5'),
('1vk17cs025', 'madhu', '5', '5');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` varchar(10) NOT NULL,
  `subject_name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `subject_name`) VALUES
('17cs51', 'ME'),
('17cs52', 'CN'),
('17cs53', 'DBMS'),
('17cs54', 'ATC'),
('17cs55', 'J2EE'),
('17cs56', 'AI'),
('17cs57', 'DAA'),
('17cs58', 'JAVA'),
('17cs59', 'PCD'),
('17cs60', 'MP'),
('17cs61', 'WORKSHOP'),
('17cs62', 'MATHS');

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `subject_id` varchar(10) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `time` varchar(10) DEFAULT NULL,
  `session` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`subject_id`, `date`, `time`, `session`) VALUES
('17cs51', '01-12-2019', '10', '  MORNING'),
('17cs52', '02-12-2019', '2', '  AFTERNOON'),
('17cs53', '03-12-2019', '10', '  MORNING'),
('17cs54', '04-12-2019', '10', '  MORNING'),
('17cs55', '05-12-2019', '10', '  MORNING'),
('17cs56', '06-12-2019', '10', '  MORNING'),
('17cs57', '09-12-2019', '2', '  AFTERNOON'),
('17cs58', '10-12-2019', '2', '  AFTERNOON'),
('17cs59', '11-12-2019', '2', '  AFTERNOON'),
('17cs60', '12-12-2019', '2', '  AFTERNOON'),
('17cs61', '13-12-2019', '2', '  AFTERNOON');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`faculty_id`),
  ADD UNIQUE KEY `faculty_id` (`faculty_id`),
  ADD KEY `fk2` (`branch_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `roomallocation`
--
ALTER TABLE `roomallocation`
  ADD KEY `fk4` (`subject_id`),
  ADD KEY `fk5` (`room_id`),
  ADD KEY `fk6` (`faculty_id`),
  ADD KEY `fk7` (`usn`);

--
-- Indexes for table `roomtrigger`
--
ALTER TABLE `roomtrigger`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`usn`),
  ADD UNIQUE KEY `usn` (`usn`),
  ADD KEY `fk1` (`branch_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD KEY `fk3` (`subject_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `roomtrigger`
--
ALTER TABLE `roomtrigger`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `faculty`
--
ALTER TABLE `faculty`
  ADD CONSTRAINT `fk2` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `roomallocation`
--
ALTER TABLE `roomallocation`
  ADD CONSTRAINT `fk4` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk5` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk6` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk7` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `fk1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timetable`
--
ALTER TABLE `timetable`
  ADD CONSTRAINT `fk3` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
